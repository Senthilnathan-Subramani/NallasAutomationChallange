n = int(input('Enter the value:'))
for x in range(n-1):
    for y in range(n, x, -1):
        print('*' if x in (n, 0) or y in (n, x + 1) else ' ', end='')
    print('')
for a in range(1, n+1):
    for b in range(0, a):
        print('*' if a in (0, n) or b in (0, a - 1) else ' ', end='')
    print('')
